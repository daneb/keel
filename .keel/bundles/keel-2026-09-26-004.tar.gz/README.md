# keel evidence bundle — run 2026-09-26-004

Spec `runtime-fixes`, driver `none`, keel 0.10.0.
Started 2026-09-26T12:12:18.121240+02:00, finished 2026-09-26T12:13:56.894569+02:00.

Base commit `33e4447ecab17d76da039abeb5b9b9ea3e92f9b4`.

## What changed

```
    12      0  .keel/chain.jsonl
     2      0  .keel/runs/2026-09-26-003/evidence/build.txt
    17      0  .keel/runs/2026-09-26-003/evidence/diff-stat.txt
   852      0  .keel/runs/2026-09-26-003/evidence/diff.patch
     2      0  .keel/runs/2026-09-26-003/evidence/lint.txt
    34      0  .keel/runs/2026-09-26-003/evidence/oracles.json
    14      0  .keel/runs/2026-09-26-003/evidence/ratchet.json
     1      0  .keel/runs/2026-09-26-003/evidence/review-test-invalidation.txt
     5      0  .keel/runs/2026-09-26-003/evidence/review.json
   130      0  .keel/runs/2026-09-26-003/evidence/test.txt
     1      0  .keel/runs/2026-09-26-003/evidence/tree.txt
    37      0  .keel/runs/2026-09-26-003/gates/G2.5.json
    84      0  .keel/runs/2026-09-26-003/gates/G2.json
    31      0  .keel/runs/2026-09-26-003/gates/G3.json
    11      0  .keel/runs/2026-09-26-003/run.json
    17      0  .keel/runs/2026-09-26-003/trajectory.jsonl
     2      0  .keel/runs/2026-09-26-004/evidence/build.txt
     2      0  .keel/runs/2026-09-26-004/evidence/lint.txt
    34      0  .keel/runs/2026-09-26-004/evidence/oracles.json
   130      0  .keel/runs/2026-09-26-004/evidence/test.txt
     9      0  .keel/runs/2026-09-26-004/run.json
    12      0  .keel/runs/2026-09-26-004/trajectory.jsonl
     3      0  .keel/specs/runtime-fixes/approvals.jsonl
    90      0  .keel/specs/runtime-fixes/gates/G0.json
    95      0  .keel/specs/runtime-fixes/gates/G1.json
    64      0  .keel/specs/runtime-fixes/plan.md
     0      0  .keel/specs/runtime-fixes/review-flags.txt
     1      0  .keel/specs/runtime-fixes/security-findings.json
    62      0  .keel/specs/runtime-fixes/spec.md
    20      0  .keel/specs/runtime-fixes/tasks.md
    39      7  runtime/action.yml
   102      0  tests/runtime_fixes.rs

32 file(s), +1915 -7 (1922 lines of churn) against 33e4447ecab17d76da039abeb5b9b9ea3e92f9b4
```

## Gates

| gate | verdict | passed | failed | blocked |
| --- | --- | --- | --- | --- |
| G2.5 | **pass** | 5 | 0 | 0 |
| G2 | **pass** | 13 | 0 | 0 |
| G3 | **pass** | 4 | 0 | 0 |

## The record

`trajectory.jsonl` holds 16 events, one JSON object per line, in sequence order.
7425 tokens were put in front of the model across 5 injection(s).

Verify this bundle has not been edited since it was written:

```sh
keel export --verify keel-<run>.tar.gz
```

Every member's SHA-256 is recorded in `manifest.json`.

## Contents

- `README.md` — this file
- `manifest.json` — member hashes
- `2026-09-26-004/` — run metadata, trajectory, gate results, evidence
- `runtime-fixes/` — the spec, plan and tasks as agreed
- `steering/` — the durable context the agent was given
