# keel evidence bundle — run 2026-09-26-002

Spec `ci-runtime`, driver `none`, keel 0.9.0.
Started 2026-09-26T10:49:55.816630+02:00, finished 2026-09-26T10:51:35.012540+02:00.

Base commit `37d387204d52f698261b8beaa66c0839ae8a57f1`.

## What changed

```
    18      0  .keel/chain.jsonl
     3      3  .keel/lesson-usage.json
     2      0  .keel/runs/2026-09-26-000/evidence/build.txt
    25      0  .keel/runs/2026-09-26-000/evidence/diff-stat.txt
  1615      0  .keel/runs/2026-09-26-000/evidence/diff.patch
     2      0  .keel/runs/2026-09-26-000/evidence/lint.txt
    73      0  .keel/runs/2026-09-26-000/evidence/oracles.json
    14      0  .keel/runs/2026-09-26-000/evidence/ratchet.json
   125      0  .keel/runs/2026-09-26-000/evidence/test.txt
     1      0  .keel/runs/2026-09-26-000/evidence/tree.txt
    85      0  .keel/runs/2026-09-26-000/gates/G2.json
    11      0  .keel/runs/2026-09-26-000/run.json
    19      0  .keel/runs/2026-09-26-000/trajectory.jsonl
     2      0  .keel/runs/2026-09-26-001/evidence/build.txt
    35      0  .keel/runs/2026-09-26-001/evidence/diff-stat.txt
  3580      0  .keel/runs/2026-09-26-001/evidence/diff.patch
     2      0  .keel/runs/2026-09-26-001/evidence/lint.txt
    73      0  .keel/runs/2026-09-26-001/evidence/oracles.json
    14      0  .keel/runs/2026-09-26-001/evidence/ratchet.json
     1      0  .keel/runs/2026-09-26-001/evidence/review-test-invalidation.txt
     5      0  .keel/runs/2026-09-26-001/evidence/review.json
   125      0  .keel/runs/2026-09-26-001/evidence/test.txt
     1      0  .keel/runs/2026-09-26-001/evidence/tree.txt
    37      0  .keel/runs/2026-09-26-001/gates/G2.5.json
    84      0  .keel/runs/2026-09-26-001/gates/G2.json
    31      0  .keel/runs/2026-09-26-001/gates/G3.json
    11      0  .keel/runs/2026-09-26-001/run.json
    22      0  .keel/runs/2026-09-26-001/trajectory.jsonl
     2      0  .keel/runs/2026-09-26-002/evidence/build.txt
     2      0  .keel/runs/2026-09-26-002/evidence/lint.txt
    73      0  .keel/runs/2026-09-26-002/evidence/oracles.json
   125      0  .keel/runs/2026-09-26-002/evidence/test.txt
     9      0  .keel/runs/2026-09-26-002/run.json
    17      0  .keel/runs/2026-09-26-002/trajectory.jsonl
     4      0  .keel/specs/ci-runtime/approvals.jsonl
    90      0  .keel/specs/ci-runtime/gates/G0.json
    95      0  .keel/specs/ci-runtime/gates/G1.json
    99      0  .keel/specs/ci-runtime/plan.md
     0      0  .keel/specs/ci-runtime/review-flags.txt
     1      0  .keel/specs/ci-runtime/security-findings.json
   111      0  .keel/specs/ci-runtime/spec.md
    34      0  .keel/specs/ci-runtime/tasks.md
   138      0  runtime/action.yml
     7      0  schemas/posture.json
     1      0  src/cmd/mod.rs
    18      0  src/cmd/runtime.rs
    33      0  src/main.rs
   231      0  src/runtime/host.rs
     2      0  src/runtime/mod.rs
   215      0  tests/ci_runtime.rs

50 file(s), +7323 -3 (7326 lines of churn) against 37d387204d52f698261b8beaa66c0839ae8a57f1
```

## Gates

| gate | verdict | passed | failed | blocked |
| --- | --- | --- | --- | --- |
| G2.5 | **pass** | 5 | 0 | 0 |
| G2 | **pass** | 13 | 0 | 0 |
| G3 | **pass** | 4 | 0 | 0 |

## The record

`trajectory.jsonl` holds 21 events, one JSON object per line, in sequence order.
7943 tokens were put in front of the model across 5 injection(s).

Verify this bundle has not been edited since it was written:

```sh
keel export --verify keel-<run>.tar.gz
```

Every member's SHA-256 is recorded in `manifest.json`.

## Contents

- `README.md` — this file
- `manifest.json` — member hashes
- `2026-09-26-002/` — run metadata, trajectory, gate results, evidence
- `ci-runtime/` — the spec, plan and tasks as agreed
- `steering/` — the durable context the agent was given
