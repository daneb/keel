# keel evidence bundle — run 2026-09-25-003

Spec `papercuts`, driver `none`, keel 0.9.0.
Started 2026-09-25T19:09:34.482227+02:00, finished 2026-09-25T19:11:18.553830+02:00.

Base commit `0b578c60eb9b9756635e5c86b7d8843866adc4a7`.

## What changed

```
    12      0  .keel/chain.jsonl
     2      0  .keel/runs/2026-09-25-002/evidence/build.txt
    22      0  .keel/runs/2026-09-25-002/evidence/diff-stat.txt
   961      0  .keel/runs/2026-09-25-002/evidence/diff.patch
     2      0  .keel/runs/2026-09-25-002/evidence/lint.txt
    49      0  .keel/runs/2026-09-25-002/evidence/oracles.json
    14      0  .keel/runs/2026-09-25-002/evidence/ratchet.json
     1      0  .keel/runs/2026-09-25-002/evidence/review-test-invalidation.txt
     5      0  .keel/runs/2026-09-25-002/evidence/review.json
   120      0  .keel/runs/2026-09-25-002/evidence/test.txt
     1      0  .keel/runs/2026-09-25-002/evidence/tree.txt
    37      0  .keel/runs/2026-09-25-002/gates/G2.5.json
    84      0  .keel/runs/2026-09-25-002/gates/G2.json
    31      0  .keel/runs/2026-09-25-002/gates/G3.json
    11      0  .keel/runs/2026-09-25-002/run.json
    19      0  .keel/runs/2026-09-25-002/trajectory.jsonl
     2      0  .keel/runs/2026-09-25-003/evidence/build.txt
     2      0  .keel/runs/2026-09-25-003/evidence/lint.txt
    49      0  .keel/runs/2026-09-25-003/evidence/oracles.json
   120      0  .keel/runs/2026-09-25-003/evidence/test.txt
     9      0  .keel/runs/2026-09-25-003/run.json
    14      0  .keel/runs/2026-09-25-003/trajectory.jsonl
     3      0  .keel/specs/papercuts/approvals.jsonl
    90      0  .keel/specs/papercuts/gates/G0.json
    95      0  .keel/specs/papercuts/gates/G1.json
    97      0  .keel/specs/papercuts/plan.md
     0      0  .keel/specs/papercuts/review-flags.txt
     1      0  .keel/specs/papercuts/security-findings.json
    81      0  .keel/specs/papercuts/spec.md
    26      0  .keel/specs/papercuts/tasks.md
     1      0  assets/drivers/claude-code
     1      0  assets/drivers/codex
     1      0  assets/drivers/copilot
     1      0  assets/drivers/kiro
     4      1  src/cover/mod.rs
    51     14  src/gate/g25.rs
    69      0  tests/papercuts.rs

37 file(s), +2088 -15 (2103 lines of churn) against 0b578c60eb9b9756635e5c86b7d8843866adc4a7
```

## Gates

| gate | verdict | passed | failed | blocked |
| --- | --- | --- | --- | --- |
| G2.5 | **pass** | 5 | 0 | 0 |
| G2 | **pass** | 13 | 0 | 0 |
| G3 | **pass** | 4 | 0 | 0 |

## The record

`trajectory.jsonl` holds 18 events, one JSON object per line, in sequence order.
7584 tokens were put in front of the model across 5 injection(s).

Verify this bundle has not been edited since it was written:

```sh
keel export --verify keel-<run>.tar.gz
```

Every member's SHA-256 is recorded in `manifest.json`.

## Contents

- `README.md` — this file
- `manifest.json` — member hashes
- `2026-09-25-003/` — run metadata, trajectory, gate results, evidence
- `papercuts/` — the spec, plan and tasks as agreed
- `steering/` — the durable context the agent was given
