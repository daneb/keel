# keel evidence bundle — run 2026-09-25-001

Spec `keel-cover`, driver `none`, keel 0.8.0.
Started 2026-09-25T15:45:02.694971+02:00, finished 2026-09-25T15:46:48.947868+02:00.

Base commit `356d8eba19e27fd4e9db028419ca77ea214cca0e`.

## What changed

```
    12      0  .keel/chain.jsonl
     3      3  .keel/lesson-usage.json
     2      0  .keel/runs/2026-09-25-000/evidence/build.txt
    24      0  .keel/runs/2026-09-25-000/evidence/diff-stat.txt
  1341      0  .keel/runs/2026-09-25-000/evidence/diff.patch
     2      0  .keel/runs/2026-09-25-000/evidence/lint.txt
    74      0  .keel/runs/2026-09-25-000/evidence/oracles.json
    14      0  .keel/runs/2026-09-25-000/evidence/ratchet.json
     1      0  .keel/runs/2026-09-25-000/evidence/review-test-invalidation.txt
     5      0  .keel/runs/2026-09-25-000/evidence/review.json
   115      0  .keel/runs/2026-09-25-000/evidence/test.txt
     1      0  .keel/runs/2026-09-25-000/evidence/tree.txt
    37      0  .keel/runs/2026-09-25-000/gates/G2.5.json
    84      0  .keel/runs/2026-09-25-000/gates/G2.json
    31      0  .keel/runs/2026-09-25-000/gates/G3.json
    11      0  .keel/runs/2026-09-25-000/run.json
    22      0  .keel/runs/2026-09-25-000/trajectory.jsonl
     2      0  .keel/runs/2026-09-25-001/evidence/build.txt
     2      0  .keel/runs/2026-09-25-001/evidence/lint.txt
    74      0  .keel/runs/2026-09-25-001/evidence/oracles.json
   115      0  .keel/runs/2026-09-25-001/evidence/test.txt
     9      0  .keel/runs/2026-09-25-001/run.json
    17      0  .keel/runs/2026-09-25-001/trajectory.jsonl
     3      0  .keel/specs/keel-cover/approvals.jsonl
    90      0  .keel/specs/keel-cover/gates/G0.json
    95      0  .keel/specs/keel-cover/gates/G1.json
   131      0  .keel/specs/keel-cover/plan.md
     0      0  .keel/specs/keel-cover/review-flags.txt
     1      0  .keel/specs/keel-cover/security-findings.json
   117      0  .keel/specs/keel-cover/spec.md
    34      0  .keel/specs/keel-cover/tasks.md
    34      0  action.yml
    27      0  schemas/cover.json
    34      0  src/cmd/cover.rs
     1      0  src/cmd/mod.rs
   160      0  src/cover/mod.rs
     1      0  src/gate/g2.rs
    10      0  src/main.rs
   180      0  tests/cover.rs

39 file(s), +2916 -3 (2919 lines of churn) against 356d8eba19e27fd4e9db028419ca77ea214cca0e
```

## Gates

| gate | verdict | passed | failed | blocked |
| --- | --- | --- | --- | --- |
| G2.5 | **pass** | 5 | 0 | 0 |
| G2 | **pass** | 13 | 0 | 0 |
| G3 | **pass** | 4 | 0 | 0 |

## The record

`trajectory.jsonl` holds 21 events, one JSON object per line, in sequence order.
7938 tokens were put in front of the model across 5 injection(s).

Verify this bundle has not been edited since it was written:

```sh
keel export --verify keel-<run>.tar.gz
```

Every member's SHA-256 is recorded in `manifest.json`.

## Contents

- `README.md` — this file
- `manifest.json` — member hashes
- `2026-09-25-001/` — run metadata, trajectory, gate results, evidence
- `keel-cover/` — the spec, plan and tasks as agreed
- `steering/` — the durable context the agent was given
